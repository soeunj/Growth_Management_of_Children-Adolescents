﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Auxology
{
    class Pinfo
    {
        private string mtend;

        public string mt_end
        {
            get
            {
                return mtend;
            }
            set
            {
                mtend = value;
            }
        }

    }
}
