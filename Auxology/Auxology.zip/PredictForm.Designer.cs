﻿namespace Auxology
{
    partial class PredictForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.xray_preview = new OpenCvSharp.UserInterface.PictureBoxIpl();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label33 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lab_I = new System.Windows.Forms.Label();
            this.lab_H = new System.Windows.Forms.Label();
            this.lab_G = new System.Windows.Forms.Label();
            this.lab_F = new System.Windows.Forms.Label();
            this.lab_E = new System.Windows.Forms.Label();
            this.lab_D = new System.Windows.Forms.Label();
            this.lab_C = new System.Windows.Forms.Label();
            this.lab_B = new System.Windows.Forms.Label();
            this.pB_TW3B = new System.Windows.Forms.PictureBox();
            this.pB_TW3C = new System.Windows.Forms.PictureBox();
            this.pB_TW3D = new System.Windows.Forms.PictureBox();
            this.pB_TW3E = new System.Windows.Forms.PictureBox();
            this.pB_TW3F = new System.Windows.Forms.PictureBox();
            this.pB_TW3G = new System.Windows.Forms.PictureBox();
            this.pB_TW3I = new System.Windows.Forms.PictureBox();
            this.pB_TW3H = new System.Windows.Forms.PictureBox();
            this.radioButton7 = new System.Windows.Forms.RadioButton();
            this.radioButton8 = new System.Windows.Forms.RadioButton();
            this.radioButton6 = new System.Windows.Forms.RadioButton();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pB_Met5 = new System.Windows.Forms.PictureBox();
            this.pB_Met3 = new System.Windows.Forms.PictureBox();
            this.pB_radius = new System.Windows.Forms.PictureBox();
            this.pB_ulna = new System.Windows.Forms.PictureBox();
            this.pB_Met1 = new System.Windows.Forms.PictureBox();
            this.pB_Pph1 = new System.Windows.Forms.PictureBox();
            this.pB_Pph3 = new System.Windows.Forms.PictureBox();
            this.pB_Pph5 = new System.Windows.Forms.PictureBox();
            this.pB_Mph3 = new System.Windows.Forms.PictureBox();
            this.pB_Dph1 = new System.Windows.Forms.PictureBox();
            this.pB_Mph5 = new System.Windows.Forms.PictureBox();
            this.pB_Dph3 = new System.Windows.Forms.PictureBox();
            this.pB_Dph5 = new System.Windows.Forms.PictureBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.reg_date = new System.Windows.Forms.DateTimePicker();
            this.birth_date = new System.Windows.Forms.DateTimePicker();
            this.chartnum_text = new System.Windows.Forms.Label();
            this.btn_search = new System.Windows.Forms.Button();
            this.chartnum_tb = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.parent_cb = new System.Windows.Forms.ComboBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xray_preview)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3E)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3F)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3G)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3I)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3H)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Met5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Met3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_radius)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_ulna)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Met1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Pph1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Pph3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Pph5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Mph3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Dph1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Mph5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Dph3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Dph5)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.xray_preview);
            this.panel1.Controls.Add(this.groupBox2);
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1732, 774);
            this.panel1.TabIndex = 0;
            // 
            // xray_preview
            // 
            this.xray_preview.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.xray_preview.Location = new System.Drawing.Point(11, 308);
            this.xray_preview.Name = "xray_preview";
            this.xray_preview.Size = new System.Drawing.Size(457, 454);
            this.xray_preview.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.xray_preview.TabIndex = 162;
            this.xray_preview.TabStop = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.textBox8);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.label34);
            this.groupBox2.Controls.Add(this.textBox9);
            this.groupBox2.Controls.Add(this.textBox11);
            this.groupBox2.Controls.Add(this.textBox10);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.label35);
            this.groupBox2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox2.Location = new System.Drawing.Point(492, 574);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox2.Size = new System.Drawing.Size(1188, 177);
            this.groupBox2.TabIndex = 199;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "골연령 계산결과";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label32.Location = new System.Drawing.Point(378, 29);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(59, 17);
            this.label32.TabIndex = 217;
            this.label32.Text = "만나이";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label30.Location = new System.Drawing.Point(41, 29);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(39, 17);
            this.label30.TabIndex = 213;
            this.label30.Text = "RUS";
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox8.Location = new System.Drawing.Point(127, 26);
            this.textBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(134, 27);
            this.textBox8.TabIndex = 19;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label31.Location = new System.Drawing.Point(41, 63);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(59, 17);
            this.label31.TabIndex = 215;
            this.label31.Text = "골연령";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label34.Location = new System.Drawing.Point(675, 62);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(25, 17);
            this.label34.TabIndex = 222;
            this.label34.Text = "세";
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox9.Location = new System.Drawing.Point(127, 61);
            this.textBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(134, 27);
            this.textBox9.TabIndex = 20;
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox11.Location = new System.Drawing.Point(534, 59);
            this.textBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(134, 27);
            this.textBox11.TabIndex = 22;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox10.Location = new System.Drawing.Point(534, 25);
            this.textBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(134, 27);
            this.textBox10.TabIndex = 21;
            // 
            // button3
            // 
            this.button3.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button3.Location = new System.Drawing.Point(775, 125);
            this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(170, 30);
            this.button3.TabIndex = 23;
            this.button3.Text = "골연령 계산";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button2.Location = new System.Drawing.Point(411, 125);
            this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(170, 30);
            this.button2.TabIndex = 23;
            this.button2.Text = "신장 그래프 보기";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button1.Location = new System.Drawing.Point(128, 125);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(170, 30);
            this.button1.TabIndex = 23;
            this.button1.Text = "골연령 계산";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label33.Location = new System.Drawing.Point(675, 27);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(25, 17);
            this.label33.TabIndex = 219;
            this.label33.Text = "세";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label35.Location = new System.Drawing.Point(377, 66);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(128, 17);
            this.label35.TabIndex = 220;
            this.label35.Text = "만나이 - 뼈나이";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lab_I);
            this.groupBox1.Controls.Add(this.lab_H);
            this.groupBox1.Controls.Add(this.lab_G);
            this.groupBox1.Controls.Add(this.lab_F);
            this.groupBox1.Controls.Add(this.lab_E);
            this.groupBox1.Controls.Add(this.lab_D);
            this.groupBox1.Controls.Add(this.lab_C);
            this.groupBox1.Controls.Add(this.lab_B);
            this.groupBox1.Controls.Add(this.pB_TW3B);
            this.groupBox1.Controls.Add(this.pB_TW3C);
            this.groupBox1.Controls.Add(this.pB_TW3D);
            this.groupBox1.Controls.Add(this.pB_TW3E);
            this.groupBox1.Controls.Add(this.pB_TW3F);
            this.groupBox1.Controls.Add(this.pB_TW3G);
            this.groupBox1.Controls.Add(this.pB_TW3I);
            this.groupBox1.Controls.Add(this.pB_TW3H);
            this.groupBox1.Controls.Add(this.radioButton7);
            this.groupBox1.Controls.Add(this.radioButton8);
            this.groupBox1.Controls.Add(this.radioButton6);
            this.groupBox1.Controls.Add(this.radioButton5);
            this.groupBox1.Controls.Add(this.radioButton1);
            this.groupBox1.Controls.Add(this.radioButton4);
            this.groupBox1.Controls.Add(this.radioButton3);
            this.groupBox1.Controls.Add(this.radioButton2);
            this.groupBox1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.groupBox1.Location = new System.Drawing.Point(492, 328);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.groupBox1.Size = new System.Drawing.Size(1188, 222);
            this.groupBox1.TabIndex = 198;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Radius 매핑 결과";
            // 
            // lab_I
            // 
            this.lab_I.AutoSize = true;
            this.lab_I.Location = new System.Drawing.Point(1047, 146);
            this.lab_I.Name = "lab_I";
            this.lab_I.Size = new System.Drawing.Size(65, 17);
            this.lab_I.TabIndex = 145;
            this.lab_I.Text = "label24";
            // 
            // lab_H
            // 
            this.lab_H.AutoSize = true;
            this.lab_H.Location = new System.Drawing.Point(909, 144);
            this.lab_H.Name = "lab_H";
            this.lab_H.Size = new System.Drawing.Size(65, 17);
            this.lab_H.TabIndex = 146;
            this.lab_H.Text = "label24";
            // 
            // lab_G
            // 
            this.lab_G.AutoSize = true;
            this.lab_G.Location = new System.Drawing.Point(784, 144);
            this.lab_G.Name = "lab_G";
            this.lab_G.Size = new System.Drawing.Size(65, 17);
            this.lab_G.TabIndex = 147;
            this.lab_G.Text = "label24";
            // 
            // lab_F
            // 
            this.lab_F.AutoSize = true;
            this.lab_F.Location = new System.Drawing.Point(630, 144);
            this.lab_F.Name = "lab_F";
            this.lab_F.Size = new System.Drawing.Size(65, 17);
            this.lab_F.TabIndex = 148;
            this.lab_F.Text = "label24";
            // 
            // lab_E
            // 
            this.lab_E.AutoSize = true;
            this.lab_E.Location = new System.Drawing.Point(492, 144);
            this.lab_E.Name = "lab_E";
            this.lab_E.Size = new System.Drawing.Size(65, 17);
            this.lab_E.TabIndex = 149;
            this.lab_E.Text = "label24";
            // 
            // lab_D
            // 
            this.lab_D.AutoSize = true;
            this.lab_D.Location = new System.Drawing.Point(338, 144);
            this.lab_D.Name = "lab_D";
            this.lab_D.Size = new System.Drawing.Size(65, 17);
            this.lab_D.TabIndex = 150;
            this.lab_D.Text = "label24";
            // 
            // lab_C
            // 
            this.lab_C.AutoSize = true;
            this.lab_C.Location = new System.Drawing.Point(192, 146);
            this.lab_C.Name = "lab_C";
            this.lab_C.Size = new System.Drawing.Size(64, 17);
            this.lab_C.TabIndex = 144;
            this.lab_C.Text = "label12";
            // 
            // lab_B
            // 
            this.lab_B.AutoSize = true;
            this.lab_B.Location = new System.Drawing.Point(46, 144);
            this.lab_B.Name = "lab_B";
            this.lab_B.Size = new System.Drawing.Size(64, 17);
            this.lab_B.TabIndex = 143;
            this.lab_B.Text = "label11";
            // 
            // pB_TW3B
            // 
            this.pB_TW3B.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_TW3B.Location = new System.Drawing.Point(40, 29);
            this.pB_TW3B.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_TW3B.Name = "pB_TW3B";
            this.pB_TW3B.Size = new System.Drawing.Size(110, 100);
            this.pB_TW3B.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_TW3B.TabIndex = 135;
            this.pB_TW3B.TabStop = false;
            // 
            // pB_TW3C
            // 
            this.pB_TW3C.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_TW3C.Location = new System.Drawing.Point(184, 29);
            this.pB_TW3C.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_TW3C.Name = "pB_TW3C";
            this.pB_TW3C.Size = new System.Drawing.Size(110, 100);
            this.pB_TW3C.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_TW3C.TabIndex = 136;
            this.pB_TW3C.TabStop = false;
            // 
            // pB_TW3D
            // 
            this.pB_TW3D.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_TW3D.Location = new System.Drawing.Point(327, 29);
            this.pB_TW3D.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_TW3D.Name = "pB_TW3D";
            this.pB_TW3D.Size = new System.Drawing.Size(110, 100);
            this.pB_TW3D.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_TW3D.TabIndex = 137;
            this.pB_TW3D.TabStop = false;
            // 
            // pB_TW3E
            // 
            this.pB_TW3E.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_TW3E.Location = new System.Drawing.Point(471, 29);
            this.pB_TW3E.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_TW3E.Name = "pB_TW3E";
            this.pB_TW3E.Size = new System.Drawing.Size(110, 100);
            this.pB_TW3E.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_TW3E.TabIndex = 138;
            this.pB_TW3E.TabStop = false;
            // 
            // pB_TW3F
            // 
            this.pB_TW3F.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_TW3F.Location = new System.Drawing.Point(614, 29);
            this.pB_TW3F.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_TW3F.Name = "pB_TW3F";
            this.pB_TW3F.Size = new System.Drawing.Size(110, 100);
            this.pB_TW3F.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_TW3F.TabIndex = 139;
            this.pB_TW3F.TabStop = false;
            // 
            // pB_TW3G
            // 
            this.pB_TW3G.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_TW3G.Location = new System.Drawing.Point(758, 29);
            this.pB_TW3G.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_TW3G.Name = "pB_TW3G";
            this.pB_TW3G.Size = new System.Drawing.Size(110, 100);
            this.pB_TW3G.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_TW3G.TabIndex = 140;
            this.pB_TW3G.TabStop = false;
            // 
            // pB_TW3I
            // 
            this.pB_TW3I.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_TW3I.Location = new System.Drawing.Point(1045, 29);
            this.pB_TW3I.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_TW3I.Name = "pB_TW3I";
            this.pB_TW3I.Size = new System.Drawing.Size(110, 100);
            this.pB_TW3I.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_TW3I.TabIndex = 141;
            this.pB_TW3I.TabStop = false;
            // 
            // pB_TW3H
            // 
            this.pB_TW3H.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_TW3H.Location = new System.Drawing.Point(901, 29);
            this.pB_TW3H.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_TW3H.Name = "pB_TW3H";
            this.pB_TW3H.Size = new System.Drawing.Size(110, 100);
            this.pB_TW3H.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_TW3H.TabIndex = 142;
            this.pB_TW3H.TabStop = false;
            // 
            // radioButton7
            // 
            this.radioButton7.AutoSize = true;
            this.radioButton7.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.radioButton7.Location = new System.Drawing.Point(936, 181);
            this.radioButton7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton7.Name = "radioButton7";
            this.radioButton7.Size = new System.Drawing.Size(36, 21);
            this.radioButton7.TabIndex = 17;
            this.radioButton7.TabStop = true;
            this.radioButton7.Text = "H";
            this.radioButton7.UseVisualStyleBackColor = true;
            // 
            // radioButton8
            // 
            this.radioButton8.AutoSize = true;
            this.radioButton8.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.radioButton8.Location = new System.Drawing.Point(1084, 181);
            this.radioButton8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton8.Name = "radioButton8";
            this.radioButton8.Size = new System.Drawing.Size(29, 21);
            this.radioButton8.TabIndex = 18;
            this.radioButton8.TabStop = true;
            this.radioButton8.Text = "I";
            this.radioButton8.UseVisualStyleBackColor = true;
            // 
            // radioButton6
            // 
            this.radioButton6.AutoSize = true;
            this.radioButton6.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.radioButton6.Location = new System.Drawing.Point(792, 181);
            this.radioButton6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton6.Name = "radioButton6";
            this.radioButton6.Size = new System.Drawing.Size(37, 21);
            this.radioButton6.TabIndex = 16;
            this.radioButton6.TabStop = true;
            this.radioButton6.Text = "G";
            this.radioButton6.UseVisualStyleBackColor = true;
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.radioButton5.Location = new System.Drawing.Point(650, 181);
            this.radioButton5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(35, 21);
            this.radioButton5.TabIndex = 15;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "F";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.radioButton1.Location = new System.Drawing.Point(75, 181);
            this.radioButton1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(36, 21);
            this.radioButton1.TabIndex = 11;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "B";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.radioButton4.Location = new System.Drawing.Point(506, 181);
            this.radioButton4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(36, 21);
            this.radioButton4.TabIndex = 14;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "E";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.radioButton3.Location = new System.Drawing.Point(362, 181);
            this.radioButton3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(36, 21);
            this.radioButton3.TabIndex = 13;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "D";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.radioButton2.Location = new System.Drawing.Point(219, 181);
            this.radioButton2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(37, 21);
            this.radioButton2.TabIndex = 12;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "C";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.pB_Met5);
            this.panel2.Controls.Add(this.pB_Met3);
            this.panel2.Controls.Add(this.pB_radius);
            this.panel2.Controls.Add(this.pB_ulna);
            this.panel2.Controls.Add(this.pB_Met1);
            this.panel2.Controls.Add(this.pB_Pph1);
            this.panel2.Controls.Add(this.pB_Pph3);
            this.panel2.Controls.Add(this.pB_Pph5);
            this.panel2.Controls.Add(this.pB_Mph3);
            this.panel2.Controls.Add(this.pB_Dph1);
            this.panel2.Controls.Add(this.pB_Mph5);
            this.panel2.Controls.Add(this.pB_Dph3);
            this.panel2.Controls.Add(this.pB_Dph5);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.label19);
            this.panel2.Controls.Add(this.label20);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.label18);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.label26);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Location = new System.Drawing.Point(4, 112);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1720, 180);
            this.panel2.TabIndex = 196;
            // 
            // pB_Met5
            // 
            this.pB_Met5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_Met5.Location = new System.Drawing.Point(512, 8);
            this.pB_Met5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_Met5.Name = "pB_Met5";
            this.pB_Met5.Size = new System.Drawing.Size(110, 100);
            this.pB_Met5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_Met5.TabIndex = 152;
            this.pB_Met5.TabStop = false;
            this.pB_Met5.Click += new System.EventHandler(this.pB_Met5_Click);
            // 
            // pB_Met3
            // 
            this.pB_Met3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_Met3.Location = new System.Drawing.Point(388, 7);
            this.pB_Met3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_Met3.Name = "pB_Met3";
            this.pB_Met3.Size = new System.Drawing.Size(110, 100);
            this.pB_Met3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_Met3.TabIndex = 153;
            this.pB_Met3.TabStop = false;
            this.pB_Met3.Click += new System.EventHandler(this.pB_Met3_Click);
            // 
            // pB_radius
            // 
            this.pB_radius.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_radius.Location = new System.Drawing.Point(18, 7);
            this.pB_radius.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_radius.Name = "pB_radius";
            this.pB_radius.Size = new System.Drawing.Size(110, 100);
            this.pB_radius.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_radius.TabIndex = 149;
            this.pB_radius.TabStop = false;
            this.pB_radius.Click += new System.EventHandler(this.pB_radius_Click);
            // 
            // pB_ulna
            // 
            this.pB_ulna.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_ulna.Location = new System.Drawing.Point(142, 7);
            this.pB_ulna.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_ulna.Name = "pB_ulna";
            this.pB_ulna.Size = new System.Drawing.Size(110, 100);
            this.pB_ulna.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_ulna.TabIndex = 150;
            this.pB_ulna.TabStop = false;
            this.pB_ulna.Click += new System.EventHandler(this.pB_ulna_Click);
            // 
            // pB_Met1
            // 
            this.pB_Met1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_Met1.Location = new System.Drawing.Point(265, 7);
            this.pB_Met1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_Met1.Name = "pB_Met1";
            this.pB_Met1.Size = new System.Drawing.Size(110, 100);
            this.pB_Met1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_Met1.TabIndex = 151;
            this.pB_Met1.TabStop = false;
            this.pB_Met1.Click += new System.EventHandler(this.pB_Met1_Click);
            // 
            // pB_Pph1
            // 
            this.pB_Pph1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_Pph1.Location = new System.Drawing.Point(635, 8);
            this.pB_Pph1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_Pph1.Name = "pB_Pph1";
            this.pB_Pph1.Size = new System.Drawing.Size(110, 100);
            this.pB_Pph1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_Pph1.TabIndex = 154;
            this.pB_Pph1.TabStop = false;
            this.pB_Pph1.Click += new System.EventHandler(this.pB_Pph1_Click);
            // 
            // pB_Pph3
            // 
            this.pB_Pph3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_Pph3.Location = new System.Drawing.Point(759, 8);
            this.pB_Pph3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_Pph3.Name = "pB_Pph3";
            this.pB_Pph3.Size = new System.Drawing.Size(110, 100);
            this.pB_Pph3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_Pph3.TabIndex = 155;
            this.pB_Pph3.TabStop = false;
            this.pB_Pph3.Click += new System.EventHandler(this.pB_Pph3_Click);
            // 
            // pB_Pph5
            // 
            this.pB_Pph5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_Pph5.Location = new System.Drawing.Point(882, 8);
            this.pB_Pph5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_Pph5.Name = "pB_Pph5";
            this.pB_Pph5.Size = new System.Drawing.Size(110, 100);
            this.pB_Pph5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_Pph5.TabIndex = 156;
            this.pB_Pph5.TabStop = false;
            this.pB_Pph5.Click += new System.EventHandler(this.pB_Pph5_Click);
            // 
            // pB_Mph3
            // 
            this.pB_Mph3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_Mph3.Location = new System.Drawing.Point(1005, 8);
            this.pB_Mph3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_Mph3.Name = "pB_Mph3";
            this.pB_Mph3.Size = new System.Drawing.Size(110, 100);
            this.pB_Mph3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_Mph3.TabIndex = 157;
            this.pB_Mph3.TabStop = false;
            this.pB_Mph3.Click += new System.EventHandler(this.pB_Mph3_Click);
            // 
            // pB_Dph1
            // 
            this.pB_Dph1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_Dph1.Location = new System.Drawing.Point(1252, 7);
            this.pB_Dph1.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_Dph1.Name = "pB_Dph1";
            this.pB_Dph1.Size = new System.Drawing.Size(110, 100);
            this.pB_Dph1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_Dph1.TabIndex = 158;
            this.pB_Dph1.TabStop = false;
            this.pB_Dph1.Click += new System.EventHandler(this.pB_Dph1_Click);
            // 
            // pB_Mph5
            // 
            this.pB_Mph5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_Mph5.Location = new System.Drawing.Point(1129, 8);
            this.pB_Mph5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_Mph5.Name = "pB_Mph5";
            this.pB_Mph5.Size = new System.Drawing.Size(110, 100);
            this.pB_Mph5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_Mph5.TabIndex = 159;
            this.pB_Mph5.TabStop = false;
            this.pB_Mph5.Click += new System.EventHandler(this.pB_Mph5_Click);
            // 
            // pB_Dph3
            // 
            this.pB_Dph3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_Dph3.Location = new System.Drawing.Point(1376, 8);
            this.pB_Dph3.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_Dph3.Name = "pB_Dph3";
            this.pB_Dph3.Size = new System.Drawing.Size(110, 100);
            this.pB_Dph3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_Dph3.TabIndex = 160;
            this.pB_Dph3.TabStop = false;
            this.pB_Dph3.Click += new System.EventHandler(this.pB_Dph3_Click);
            // 
            // pB_Dph5
            // 
            this.pB_Dph5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pB_Dph5.Location = new System.Drawing.Point(1499, 7);
            this.pB_Dph5.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this.pB_Dph5.Name = "pB_Dph5";
            this.pB_Dph5.Size = new System.Drawing.Size(110, 100);
            this.pB_Dph5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pB_Dph5.TabIndex = 161;
            this.pB_Dph5.TabStop = false;
            this.pB_Dph5.Click += new System.EventHandler(this.pB_Dph5_Click);
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label22.Location = new System.Drawing.Point(1170, 111);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(33, 30);
            this.label22.TabIndex = 144;
            this.label22.Text = "Ⅴ";
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label23.Location = new System.Drawing.Point(1046, 107);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(33, 30);
            this.label23.TabIndex = 143;
            this.label23.Text = "Ⅲ";
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label19.Location = new System.Drawing.Point(1546, 107);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(33, 30);
            this.label19.TabIndex = 141;
            this.label19.Text = "Ⅴ";
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label20.Location = new System.Drawing.Point(1415, 107);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(33, 30);
            this.label20.TabIndex = 140;
            this.label20.Text = "Ⅲ";
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label21.Location = new System.Drawing.Point(1292, 107);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(33, 30);
            this.label21.TabIndex = 139;
            this.label21.Text = "Ⅰ";
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label16.Location = new System.Drawing.Point(923, 107);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(33, 30);
            this.label16.TabIndex = 138;
            this.label16.Text = "Ⅴ";
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label17.Location = new System.Drawing.Point(803, 107);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(33, 30);
            this.label17.TabIndex = 137;
            this.label17.Text = "Ⅲ";
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label18.Location = new System.Drawing.Point(677, 107);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(33, 30);
            this.label18.TabIndex = 136;
            this.label18.Text = "Ⅰ";
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label15.Location = new System.Drawing.Point(551, 107);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(33, 30);
            this.label15.TabIndex = 135;
            this.label15.Text = "Ⅴ";
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.Location = new System.Drawing.Point(426, 107);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(33, 30);
            this.label14.TabIndex = 134;
            this.label14.Text = "Ⅲ";
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("맑은 고딕", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.Location = new System.Drawing.Point(302, 107);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(33, 30);
            this.label13.TabIndex = 133;
            this.label13.Text = "Ⅰ";
            // 
            // label27
            // 
            this.label27.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label27.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label27.Location = new System.Drawing.Point(1377, 148);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(109, 17);
            this.label27.TabIndex = 148;
            this.label27.Text = "D.phalanges";
            // 
            // label26
            // 
            this.label26.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label26.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label26.Location = new System.Drawing.Point(1069, 148);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(112, 17);
            this.label26.TabIndex = 147;
            this.label26.Text = "M.phalanges";
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label11.Location = new System.Drawing.Point(40, 148);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 17);
            this.label11.TabIndex = 131;
            this.label11.Text = "Radius";
            // 
            // label25
            // 
            this.label25.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label25.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label25.Location = new System.Drawing.Point(760, 148);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(109, 17);
            this.label25.TabIndex = 146;
            this.label25.Text = "P.phalanges";
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label12.Location = new System.Drawing.Point(170, 148);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 17);
            this.label12.TabIndex = 132;
            this.label12.Text = "Ulna";
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label24.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.label24.Location = new System.Drawing.Point(371, 148);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(98, 17);
            this.label24.TabIndex = 145;
            this.label24.Text = "Metacarpal";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.reg_date);
            this.panel3.Controls.Add(this.birth_date);
            this.panel3.Controls.Add(this.chartnum_text);
            this.panel3.Controls.Add(this.btn_search);
            this.panel3.Controls.Add(this.chartnum_tb);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.textBox1);
            this.panel3.Controls.Add(this.textBox7);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.textBox6);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.textBox5);
            this.panel3.Controls.Add(this.textBox4);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.parent_cb);
            this.panel3.Location = new System.Drawing.Point(4, 10);
            this.panel3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1720, 98);
            this.panel3.TabIndex = 195;
            // 
            // reg_date
            // 
            this.reg_date.CalendarFont = new System.Drawing.Font("굴림", 12.75F);
            this.reg_date.Location = new System.Drawing.Point(904, 5);
            this.reg_date.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.reg_date.Name = "reg_date";
            this.reg_date.Size = new System.Drawing.Size(134, 21);
            this.reg_date.TabIndex = 115;
            // 
            // birth_date
            // 
            this.birth_date.CalendarFont = new System.Drawing.Font("굴림", 12.75F);
            this.birth_date.Location = new System.Drawing.Point(142, 37);
            this.birth_date.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.birth_date.Name = "birth_date";
            this.birth_date.Size = new System.Drawing.Size(134, 21);
            this.birth_date.TabIndex = 4;
            // 
            // chartnum_text
            // 
            this.chartnum_text.AutoSize = true;
            this.chartnum_text.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.chartnum_text.Location = new System.Drawing.Point(38, 5);
            this.chartnum_text.Name = "chartnum_text";
            this.chartnum_text.Size = new System.Drawing.Size(81, 17);
            this.chartnum_text.TabIndex = 95;
            this.chartnum_text.Text = "차트 번호";
            // 
            // btn_search
            // 
            this.btn_search.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_search.Location = new System.Drawing.Point(1099, 70);
            this.btn_search.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(66, 23);
            this.btn_search.TabIndex = 10;
            this.btn_search.Text = "검색";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // chartnum_tb
            // 
            this.chartnum_tb.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.chartnum_tb.Location = new System.Drawing.Point(142, 2);
            this.chartnum_tb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chartnum_tb.Name = "chartnum_tb";
            this.chartnum_tb.ReadOnly = true;
            this.chartnum_tb.Size = new System.Drawing.Size(134, 27);
            this.chartnum_tb.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(379, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 17);
            this.label1.TabIndex = 97;
            this.label1.Text = "이름";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("굴림", 12.75F);
            this.label9.Location = new System.Drawing.Point(1043, 70);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(25, 17);
            this.label9.TabIndex = 114;
            this.label9.Text = "kg";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox1.Location = new System.Drawing.Point(482, 2);
            this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(134, 27);
            this.textBox1.TabIndex = 2;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox7.Location = new System.Drawing.Point(904, 66);
            this.textBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(134, 27);
            this.textBox7.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(769, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(122, 17);
            this.label2.TabIndex = 99;
            this.label2.Text = "내원일(등록일)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(769, 67);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(98, 17);
            this.label10.TabIndex = 112;
            this.label10.Text = "과거 몸무게";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(629, 69);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(30, 17);
            this.label8.TabIndex = 111;
            this.label8.Text = "cm";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(38, 36);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 17);
            this.label3.TabIndex = 101;
            this.label3.Text = "생년월일";
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox6.Location = new System.Drawing.Point(482, 65);
            this.textBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(134, 27);
            this.textBox6.TabIndex = 8;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(379, 67);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 17);
            this.label7.TabIndex = 109;
            this.label7.Text = "과거신장";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label4.Location = new System.Drawing.Point(769, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 17);
            this.label4.TabIndex = 103;
            this.label4.Text = "초경일자(여아)";
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox5.Location = new System.Drawing.Point(142, 67);
            this.textBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(134, 27);
            this.textBox5.TabIndex = 7;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.textBox4.Location = new System.Drawing.Point(904, 33);
            this.textBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(134, 27);
            this.textBox4.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(38, 67);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 17);
            this.label6.TabIndex = 107;
            this.label6.Text = "과거측정일";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label5.Location = new System.Drawing.Point(379, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(42, 17);
            this.label5.TabIndex = 105;
            this.label5.Text = "성별";
            // 
            // parent_cb
            // 
            this.parent_cb.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.parent_cb.FormattingEnabled = true;
            this.parent_cb.Items.AddRange(new object[] {
            "남",
            "녀"});
            this.parent_cb.Location = new System.Drawing.Point(482, 33);
            this.parent_cb.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.parent_cb.Name = "parent_cb";
            this.parent_cb.Size = new System.Drawing.Size(134, 25);
            this.parent_cb.TabIndex = 5;
            // 
            // panel4
            // 
            this.panel4.Location = new System.Drawing.Point(4, 305);
            this.panel4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(472, 460);
            this.panel4.TabIndex = 201;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // PredictForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1732, 774);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "PredictForm";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "PredictForm";
            this.Load += new System.EventHandler(this.PredictForm_Load);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xray_preview)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3E)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3F)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3G)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3I)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_TW3H)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Met5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Met3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_radius)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_ulna)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Met1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Pph1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Pph3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Pph5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Mph3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Dph1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Mph5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Dph3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pB_Dph5)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label chartnum_text;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.TextBox chartnum_tb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox parent_cb;
        private System.Windows.Forms.DateTimePicker birth_date;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton radioButton7;
        private System.Windows.Forms.RadioButton radioButton8;
        private System.Windows.Forms.RadioButton radioButton6;
        private System.Windows.Forms.RadioButton radioButton5;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.DateTimePicker reg_date;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lab_I;
        private System.Windows.Forms.Label lab_H;
        private System.Windows.Forms.Label lab_G;
        private System.Windows.Forms.Label lab_F;
        private System.Windows.Forms.Label lab_E;
        private System.Windows.Forms.Label lab_D;
        private System.Windows.Forms.Label lab_C;
        private System.Windows.Forms.Label lab_B;
        private System.Windows.Forms.PictureBox pB_TW3B;
        private System.Windows.Forms.PictureBox pB_TW3C;
        private System.Windows.Forms.PictureBox pB_TW3D;
        private System.Windows.Forms.PictureBox pB_TW3E;
        private System.Windows.Forms.PictureBox pB_TW3F;
        private System.Windows.Forms.PictureBox pB_TW3G;
        private System.Windows.Forms.PictureBox pB_TW3I;
        private System.Windows.Forms.PictureBox pB_TW3H;
        private System.Windows.Forms.PictureBox pB_Met5;
        private System.Windows.Forms.PictureBox pB_Met3;
        private System.Windows.Forms.PictureBox pB_radius;
        private System.Windows.Forms.PictureBox pB_ulna;
        private System.Windows.Forms.PictureBox pB_Met1;
        private System.Windows.Forms.PictureBox pB_Pph1;
        private System.Windows.Forms.PictureBox pB_Pph3;
        private System.Windows.Forms.PictureBox pB_Pph5;
        private System.Windows.Forms.PictureBox pB_Mph3;
        private System.Windows.Forms.PictureBox pB_Dph1;
        private System.Windows.Forms.PictureBox pB_Mph5;
        private System.Windows.Forms.PictureBox pB_Dph3;
        private System.Windows.Forms.PictureBox pB_Dph5;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Panel panel4;
        private OpenCvSharp.UserInterface.PictureBoxIpl xray_preview;
    }
}