﻿namespace Auxology
{
    partial class Munjin1Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.reg_date = new System.Windows.Forms.DateTimePicker();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.tb18_1 = new System.Windows.Forms.TextBox();
            this.panel36 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel35 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.tb17_1 = new System.Windows.Forms.TextBox();
            this.panel34 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.tb16_2 = new System.Windows.Forms.TextBox();
            this.tb16_1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.panel31 = new System.Windows.Forms.Panel();
            this.cb15_5 = new System.Windows.Forms.CheckBox();
            this.cb15_4 = new System.Windows.Forms.CheckBox();
            this.cb15_3 = new System.Windows.Forms.CheckBox();
            this.cb15_2 = new System.Windows.Forms.CheckBox();
            this.cb15_1 = new System.Windows.Forms.CheckBox();
            this.panel30 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.cb14_6 = new System.Windows.Forms.CheckBox();
            this.cb14_5 = new System.Windows.Forms.CheckBox();
            this.cb14_4 = new System.Windows.Forms.CheckBox();
            this.cb14_3 = new System.Windows.Forms.CheckBox();
            this.cb14_2 = new System.Windows.Forms.CheckBox();
            this.cb14_1 = new System.Windows.Forms.CheckBox();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.tb13_2 = new System.Windows.Forms.TextBox();
            this.tb13_1 = new System.Windows.Forms.TextBox();
            this.cb13_2 = new System.Windows.Forms.CheckBox();
            this.cb13_1 = new System.Windows.Forms.CheckBox();
            this.panel26 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.cb12_5 = new System.Windows.Forms.CheckBox();
            this.cb12_4 = new System.Windows.Forms.CheckBox();
            this.cb12_3 = new System.Windows.Forms.CheckBox();
            this.cb12_2 = new System.Windows.Forms.CheckBox();
            this.cb12_1 = new System.Windows.Forms.CheckBox();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.cb11_4 = new System.Windows.Forms.CheckBox();
            this.cb11_3 = new System.Windows.Forms.CheckBox();
            this.cb11_2 = new System.Windows.Forms.CheckBox();
            this.cb11_1 = new System.Windows.Forms.CheckBox();
            this.panel22 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.cb10_3 = new System.Windows.Forms.CheckBox();
            this.cb10_2 = new System.Windows.Forms.CheckBox();
            this.cb10_1 = new System.Windows.Forms.CheckBox();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label13 = new System.Windows.Forms.Label();
            this.panel19 = new System.Windows.Forms.Panel();
            this.cb9_5 = new System.Windows.Forms.CheckBox();
            this.cb9_4 = new System.Windows.Forms.CheckBox();
            this.cb9_3 = new System.Windows.Forms.CheckBox();
            this.cb9_2 = new System.Windows.Forms.CheckBox();
            this.cb9_1 = new System.Windows.Forms.CheckBox();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.cb8_3 = new System.Windows.Forms.CheckBox();
            this.cb8_2 = new System.Windows.Forms.CheckBox();
            this.cb8_1 = new System.Windows.Forms.CheckBox();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.cb7_5 = new System.Windows.Forms.CheckBox();
            this.cb7_4 = new System.Windows.Forms.CheckBox();
            this.cb7_3 = new System.Windows.Forms.CheckBox();
            this.cb7_2 = new System.Windows.Forms.CheckBox();
            this.cb7_1 = new System.Windows.Forms.CheckBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.tb6_1 = new System.Windows.Forms.TextBox();
            this.cb6_4 = new System.Windows.Forms.CheckBox();
            this.cb6_3 = new System.Windows.Forms.CheckBox();
            this.cb6_2 = new System.Windows.Forms.CheckBox();
            this.cb6_1 = new System.Windows.Forms.CheckBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.tb5_1 = new System.Windows.Forms.TextBox();
            this.tb5_4 = new System.Windows.Forms.TextBox();
            this.tb5_3 = new System.Windows.Forms.TextBox();
            this.tb5_2 = new System.Windows.Forms.TextBox();
            this.cb5_4 = new System.Windows.Forms.CheckBox();
            this.cb5_3 = new System.Windows.Forms.CheckBox();
            this.cb5_2 = new System.Windows.Forms.CheckBox();
            this.cb5_1 = new System.Windows.Forms.CheckBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.tb4_1 = new System.Windows.Forms.TextBox();
            this.cb4_3 = new System.Windows.Forms.CheckBox();
            this.cb4_2 = new System.Windows.Forms.CheckBox();
            this.cb4_1 = new System.Windows.Forms.CheckBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.cb3_4 = new System.Windows.Forms.CheckBox();
            this.cb3_3 = new System.Windows.Forms.CheckBox();
            this.cb3_2 = new System.Windows.Forms.CheckBox();
            this.cb3_1 = new System.Windows.Forms.CheckBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.tb2_1 = new System.Windows.Forms.TextBox();
            this.cb2_5 = new System.Windows.Forms.CheckBox();
            this.cb2_4 = new System.Windows.Forms.CheckBox();
            this.cb2_3 = new System.Windows.Forms.CheckBox();
            this.cb2_2 = new System.Windows.Forms.CheckBox();
            this.cb2_1 = new System.Windows.Forms.CheckBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.tb1_1 = new System.Windows.Forms.TextBox();
            this.cb1_2 = new System.Windows.Forms.CheckBox();
            this.cb1_1 = new System.Windows.Forms.CheckBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.name_tb = new System.Windows.Forms.TextBox();
            this.nametext = new System.Windows.Forms.Label();
            this.btn_search = new System.Windows.Forms.Button();
            this.chartnum_tb = new System.Windows.Forms.TextBox();
            this.rdatetext = new System.Windows.Forms.Label();
            this.charttext = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel13.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.reg_date);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Controls.Add(this.name_tb);
            this.panel1.Controls.Add(this.nametext);
            this.panel1.Controls.Add(this.btn_search);
            this.panel1.Controls.Add(this.chartnum_tb);
            this.panel1.Controls.Add(this.rdatetext);
            this.panel1.Controls.Add(this.charttext);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1980, 968);
            this.panel1.TabIndex = 0;
            // 
            // reg_date
            // 
            this.reg_date.CalendarFont = new System.Drawing.Font("굴림", 12.75F);
            this.reg_date.Location = new System.Drawing.Point(950, 16);
            this.reg_date.Name = "reg_date";
            this.reg_date.Size = new System.Drawing.Size(153, 21);
            this.reg_date.TabIndex = 4;
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button2.Location = new System.Drawing.Point(1579, 712);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(55, 29);
            this.button2.TabIndex = 80;
            this.button2.Text = "삭제";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.button1.Location = new System.Drawing.Point(1476, 712);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(55, 29);
            this.button1.TabIndex = 79;
            this.button1.Text = "저장";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 26.59915F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 73.40085F));
            this.tableLayoutPanel1.Controls.Add(this.panel37, 1, 17);
            this.tableLayoutPanel1.Controls.Add(this.panel36, 0, 17);
            this.tableLayoutPanel1.Controls.Add(this.panel35, 1, 16);
            this.tableLayoutPanel1.Controls.Add(this.panel34, 0, 16);
            this.tableLayoutPanel1.Controls.Add(this.panel33, 1, 15);
            this.tableLayoutPanel1.Controls.Add(this.panel32, 0, 15);
            this.tableLayoutPanel1.Controls.Add(this.panel31, 1, 14);
            this.tableLayoutPanel1.Controls.Add(this.panel30, 0, 14);
            this.tableLayoutPanel1.Controls.Add(this.panel29, 1, 13);
            this.tableLayoutPanel1.Controls.Add(this.panel28, 0, 13);
            this.tableLayoutPanel1.Controls.Add(this.panel27, 1, 12);
            this.tableLayoutPanel1.Controls.Add(this.panel26, 0, 12);
            this.tableLayoutPanel1.Controls.Add(this.panel25, 1, 11);
            this.tableLayoutPanel1.Controls.Add(this.panel24, 0, 11);
            this.tableLayoutPanel1.Controls.Add(this.panel23, 1, 10);
            this.tableLayoutPanel1.Controls.Add(this.panel22, 0, 10);
            this.tableLayoutPanel1.Controls.Add(this.panel21, 1, 9);
            this.tableLayoutPanel1.Controls.Add(this.panel20, 0, 9);
            this.tableLayoutPanel1.Controls.Add(this.panel19, 1, 8);
            this.tableLayoutPanel1.Controls.Add(this.panel18, 0, 8);
            this.tableLayoutPanel1.Controls.Add(this.panel17, 1, 7);
            this.tableLayoutPanel1.Controls.Add(this.panel16, 0, 7);
            this.tableLayoutPanel1.Controls.Add(this.panel15, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel14, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.panel13, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel12, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.panel11, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel10, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.panel9, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel8, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.panel7, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel6, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.panel5, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel4, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(18, 77);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 18;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 6.8F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.5F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 5.2F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1872, 620);
            this.tableLayoutPanel1.TabIndex = 330;
            // 
            // panel37
            // 
            this.panel37.Controls.Add(this.tb18_1);
            this.panel37.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel37.Location = new System.Drawing.Point(502, 589);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(1366, 27);
            this.panel37.TabIndex = 35;
            // 
            // tb18_1
            // 
            this.tb18_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb18_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb18_1.Location = new System.Drawing.Point(39, 0);
            this.tb18_1.Name = "tb18_1";
            this.tb18_1.Size = new System.Drawing.Size(86, 27);
            this.tb18_1.TabIndex = 78;
            // 
            // panel36
            // 
            this.panel36.Controls.Add(this.label3);
            this.panel36.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel36.Location = new System.Drawing.Point(4, 589);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(491, 27);
            this.panel36.TabIndex = 34;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label3.Location = new System.Drawing.Point(3, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(347, 17);
            this.label3.TabIndex = 449;
            this.label3.Text = "향후 귀댁 자녀가 원하는 직업은 무엇입니까?";
            // 
            // panel35
            // 
            this.panel35.Controls.Add(this.label1);
            this.panel35.Controls.Add(this.tb17_1);
            this.panel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel35.Location = new System.Drawing.Point(502, 555);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(1366, 27);
            this.panel35.TabIndex = 33;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label1.Location = new System.Drawing.Point(132, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 17);
            this.label1.TabIndex = 523;
            this.label1.Text = "cm";
            // 
            // tb17_1
            // 
            this.tb17_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb17_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb17_1.Location = new System.Drawing.Point(39, 0);
            this.tb17_1.Name = "tb17_1";
            this.tb17_1.Size = new System.Drawing.Size(86, 27);
            this.tb17_1.TabIndex = 77;
            // 
            // panel34
            // 
            this.panel34.Controls.Add(this.label6);
            this.panel34.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel34.Location = new System.Drawing.Point(4, 555);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(491, 27);
            this.panel34.TabIndex = 32;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label6.Location = new System.Drawing.Point(3, 4);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(369, 17);
            this.label6.TabIndex = 448;
            this.label6.Text = "향후 귀댁 자녀가 원하는 키는 얼마정도 입니까?";
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.tb16_2);
            this.panel33.Controls.Add(this.tb16_1);
            this.panel33.Controls.Add(this.label2);
            this.panel33.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel33.Location = new System.Drawing.Point(502, 521);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(1366, 27);
            this.panel33.TabIndex = 31;
            // 
            // tb16_2
            // 
            this.tb16_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb16_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb16_2.Location = new System.Drawing.Point(315, 0);
            this.tb16_2.Name = "tb16_2";
            this.tb16_2.Size = new System.Drawing.Size(58, 27);
            this.tb16_2.TabIndex = 76;
            // 
            // tb16_1
            // 
            this.tb16_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb16_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb16_1.Location = new System.Drawing.Point(137, 0);
            this.tb16_1.Name = "tb16_1";
            this.tb16_1.Size = new System.Drawing.Size(58, 27);
            this.tb16_1.TabIndex = 75;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label2.Location = new System.Drawing.Point(36, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(440, 17);
            this.label2.TabIndex = 520;
            this.label2.Text = "평균적으로               시쯤 자며 하루             시간 잡니다.";
            // 
            // panel32
            // 
            this.panel32.Controls.Add(this.label7);
            this.panel32.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel32.Location = new System.Drawing.Point(4, 521);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(491, 27);
            this.panel32.TabIndex = 30;
            // 
            // label7
            // 
            this.label7.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label7.Location = new System.Drawing.Point(3, 4);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(325, 17);
            this.label7.TabIndex = 447;
            this.label7.Text = "현재 귀댁 자녀의 취침습관은 어떻습니까?";
            // 
            // panel31
            // 
            this.panel31.Controls.Add(this.cb15_5);
            this.panel31.Controls.Add(this.cb15_4);
            this.panel31.Controls.Add(this.cb15_3);
            this.panel31.Controls.Add(this.cb15_2);
            this.panel31.Controls.Add(this.cb15_1);
            this.panel31.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel31.Location = new System.Drawing.Point(502, 487);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(1366, 27);
            this.panel31.TabIndex = 29;
            // 
            // cb15_5
            // 
            this.cb15_5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb15_5.AutoSize = true;
            this.cb15_5.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb15_5.Location = new System.Drawing.Point(803, 3);
            this.cb15_5.Name = "cb15_5";
            this.cb15_5.Size = new System.Drawing.Size(66, 21);
            this.cb15_5.TabIndex = 74;
            this.cb15_5.Text = "음 모";
            this.cb15_5.UseVisualStyleBackColor = true;
            // 
            // cb15_4
            // 
            this.cb15_4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb15_4.AutoSize = true;
            this.cb15_4.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb15_4.Location = new System.Drawing.Point(636, 3);
            this.cb15_4.Name = "cb15_4";
            this.cb15_4.Size = new System.Drawing.Size(95, 21);
            this.cb15_4.TabIndex = 73;
            this.cb15_4.Text = "유두커짐";
            this.cb15_4.UseVisualStyleBackColor = true;
            // 
            // cb15_3
            // 
            this.cb15_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb15_3.AutoSize = true;
            this.cb15_3.Enabled = false;
            this.cb15_3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb15_3.Location = new System.Drawing.Point(406, 4);
            this.cb15_3.Name = "cb15_3";
            this.cb15_3.Size = new System.Drawing.Size(168, 21);
            this.cb15_3.TabIndex = 72;
            this.cb15_3.Text = "성조숙증이 있었다";
            this.cb15_3.UseVisualStyleBackColor = true;
            // 
            // cb15_2
            // 
            this.cb15_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb15_2.AutoSize = true;
            this.cb15_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb15_2.Location = new System.Drawing.Point(250, 3);
            this.cb15_2.Name = "cb15_2";
            this.cb15_2.Size = new System.Drawing.Size(338, 21);
            this.cb15_2.TabIndex = 71;
            this.cb15_2.Text = "사춘기가 빨랐다(                                   )";
            this.cb15_2.UseVisualStyleBackColor = true;
            this.cb15_2.CheckedChanged += new System.EventHandler(this.cb15_2_CheckedChanged);
            // 
            // cb15_1
            // 
            this.cb15_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb15_1.AutoSize = true;
            this.cb15_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb15_1.Location = new System.Drawing.Point(39, 3);
            this.cb15_1.Name = "cb15_1";
            this.cb15_1.Size = new System.Drawing.Size(66, 21);
            this.cb15_1.TabIndex = 70;
            this.cb15_1.Text = "정 상";
            this.cb15_1.UseVisualStyleBackColor = true;
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.label8);
            this.panel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel30.Location = new System.Drawing.Point(4, 487);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(491, 27);
            this.panel30.TabIndex = 28;
            // 
            // label8
            // 
            this.label8.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label8.Location = new System.Drawing.Point(3, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(303, 17);
            this.label8.TabIndex = 446;
            this.label8.Text = "과거 부모님의 사춘기는 어떠했습니까?";
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.cb14_6);
            this.panel29.Controls.Add(this.cb14_5);
            this.panel29.Controls.Add(this.cb14_4);
            this.panel29.Controls.Add(this.cb14_3);
            this.panel29.Controls.Add(this.cb14_2);
            this.panel29.Controls.Add(this.cb14_1);
            this.panel29.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel29.Location = new System.Drawing.Point(502, 453);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(1366, 27);
            this.panel29.TabIndex = 27;
            // 
            // cb14_6
            // 
            this.cb14_6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb14_6.AutoSize = true;
            this.cb14_6.Enabled = false;
            this.cb14_6.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb14_6.Location = new System.Drawing.Point(726, 3);
            this.cb14_6.Name = "cb14_6";
            this.cb14_6.Size = new System.Drawing.Size(61, 21);
            this.cb14_6.TabIndex = 69;
            this.cb14_6.Text = "아빠";
            this.cb14_6.UseVisualStyleBackColor = true;
            // 
            // cb14_5
            // 
            this.cb14_5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb14_5.AutoSize = true;
            this.cb14_5.Enabled = false;
            this.cb14_5.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb14_5.Location = new System.Drawing.Point(663, 3);
            this.cb14_5.Name = "cb14_5";
            this.cb14_5.Size = new System.Drawing.Size(61, 21);
            this.cb14_5.TabIndex = 68;
            this.cb14_5.Text = "엄마";
            this.cb14_5.UseVisualStyleBackColor = true;
            // 
            // cb14_4
            // 
            this.cb14_4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb14_4.AutoSize = true;
            this.cb14_4.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb14_4.Location = new System.Drawing.Point(636, 3);
            this.cb14_4.Name = "cb14_4";
            this.cb14_4.Size = new System.Drawing.Size(310, 21);
            this.cb14_4.TabIndex = 67;
            this.cb14_4.Text = "(                         ) 에게만 순종적이다";
            this.cb14_4.UseVisualStyleBackColor = true;
            this.cb14_4.CheckedChanged += new System.EventHandler(this.cb14_4_CheckedChanged);
            // 
            // cb14_3
            // 
            this.cb14_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb14_3.AutoSize = true;
            this.cb14_3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb14_3.Location = new System.Drawing.Point(457, 3);
            this.cb14_3.Name = "cb14_3";
            this.cb14_3.Size = new System.Drawing.Size(112, 21);
            this.cb14_3.TabIndex = 66;
            this.cb14_3.Text = "순종적이다";
            this.cb14_3.UseVisualStyleBackColor = true;
            // 
            // cb14_2
            // 
            this.cb14_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb14_2.AutoSize = true;
            this.cb14_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb14_2.Location = new System.Drawing.Point(250, 3);
            this.cb14_2.Name = "cb14_2";
            this.cb14_2.Size = new System.Drawing.Size(112, 21);
            this.cb14_2.TabIndex = 65;
            this.cb14_2.Text = "반항적이다";
            this.cb14_2.UseVisualStyleBackColor = true;
            // 
            // cb14_1
            // 
            this.cb14_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb14_1.AutoSize = true;
            this.cb14_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb14_1.Location = new System.Drawing.Point(39, 3);
            this.cb14_1.Name = "cb14_1";
            this.cb14_1.Size = new System.Drawing.Size(95, 21);
            this.cb14_1.TabIndex = 64;
            this.cb14_1.Text = "원만하다";
            this.cb14_1.UseVisualStyleBackColor = true;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.label9);
            this.panel28.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel28.Location = new System.Drawing.Point(4, 453);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(491, 27);
            this.panel28.TabIndex = 26;
            // 
            // label9
            // 
            this.label9.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label9.Location = new System.Drawing.Point(3, 4);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(381, 17);
            this.label9.TabIndex = 445;
            this.label9.Text = "현재 귀댁 자녀와 부모님과의 관계는 어떻습니까?";
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.tb13_2);
            this.panel27.Controls.Add(this.tb13_1);
            this.panel27.Controls.Add(this.cb13_2);
            this.panel27.Controls.Add(this.cb13_1);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.Location = new System.Drawing.Point(502, 419);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(1366, 27);
            this.panel27.TabIndex = 25;
            // 
            // tb13_2
            // 
            this.tb13_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb13_2.Enabled = false;
            this.tb13_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb13_2.Location = new System.Drawing.Point(259, 0);
            this.tb13_2.Name = "tb13_2";
            this.tb13_2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.tb13_2.Size = new System.Drawing.Size(58, 27);
            this.tb13_2.TabIndex = 62;
            // 
            // tb13_1
            // 
            this.tb13_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb13_1.Enabled = false;
            this.tb13_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb13_1.Location = new System.Drawing.Point(172, 0);
            this.tb13_1.Name = "tb13_1";
            this.tb13_1.Size = new System.Drawing.Size(58, 27);
            this.tb13_1.TabIndex = 61;
            // 
            // cb13_2
            // 
            this.cb13_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb13_2.AutoSize = true;
            this.cb13_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb13_2.Location = new System.Drawing.Point(457, 3);
            this.cb13_2.Name = "cb13_2";
            this.cb13_2.Size = new System.Drawing.Size(44, 21);
            this.cb13_2.TabIndex = 63;
            this.cb13_2.Text = "무";
            this.cb13_2.UseVisualStyleBackColor = true;
            // 
            // cb13_1
            // 
            this.cb13_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb13_1.AutoSize = true;
            this.cb13_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb13_1.Location = new System.Drawing.Point(39, 4);
            this.cb13_1.Name = "cb13_1";
            this.cb13_1.Size = new System.Drawing.Size(330, 21);
            this.cb13_1.TabIndex = 60;
            this.cb13_1.Text = "유(초경시기:                세              개월)";
            this.cb13_1.UseVisualStyleBackColor = true;
            this.cb13_1.CheckedChanged += new System.EventHandler(this.cb13_1_CheckedChanged);
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.label10);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel26.Location = new System.Drawing.Point(4, 419);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(491, 27);
            this.panel26.TabIndex = 24;
            // 
            // label10
            // 
            this.label10.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label10.Location = new System.Drawing.Point(3, 4);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(320, 17);
            this.label10.TabIndex = 444;
            this.label10.Text = "(여아) 귀댁 따님의 초경은 언제였습니까?";
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.cb12_5);
            this.panel25.Controls.Add(this.cb12_4);
            this.panel25.Controls.Add(this.cb12_3);
            this.panel25.Controls.Add(this.cb12_2);
            this.panel25.Controls.Add(this.cb12_1);
            this.panel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel25.Location = new System.Drawing.Point(502, 385);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(1366, 27);
            this.panel25.TabIndex = 23;
            // 
            // cb12_5
            // 
            this.cb12_5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb12_5.AutoSize = true;
            this.cb12_5.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb12_5.Location = new System.Drawing.Point(803, 3);
            this.cb12_5.Name = "cb12_5";
            this.cb12_5.Size = new System.Drawing.Size(66, 21);
            this.cb12_5.TabIndex = 59;
            this.cb12_5.Text = "음 모";
            this.cb12_5.UseVisualStyleBackColor = true;
            // 
            // cb12_4
            // 
            this.cb12_4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb12_4.AutoSize = true;
            this.cb12_4.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb12_4.Location = new System.Drawing.Point(636, 3);
            this.cb12_4.Name = "cb12_4";
            this.cb12_4.Size = new System.Drawing.Size(95, 21);
            this.cb12_4.TabIndex = 58;
            this.cb12_4.Text = "유두커짐";
            this.cb12_4.UseVisualStyleBackColor = true;
            // 
            // cb12_3
            // 
            this.cb12_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb12_3.AutoSize = true;
            this.cb12_3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb12_3.Location = new System.Drawing.Point(457, 3);
            this.cb12_3.Name = "cb12_3";
            this.cb12_3.Size = new System.Drawing.Size(66, 21);
            this.cb12_3.TabIndex = 57;
            this.cb12_3.Text = "생 리";
            this.cb12_3.UseVisualStyleBackColor = true;
            // 
            // cb12_2
            // 
            this.cb12_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb12_2.AutoSize = true;
            this.cb12_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb12_2.Location = new System.Drawing.Point(250, 3);
            this.cb12_2.Name = "cb12_2";
            this.cb12_2.Size = new System.Drawing.Size(78, 21);
            this.cb12_2.TabIndex = 56;
            this.cb12_2.Text = "변성기";
            this.cb12_2.UseVisualStyleBackColor = true;
            // 
            // cb12_1
            // 
            this.cb12_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb12_1.AutoSize = true;
            this.cb12_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb12_1.Location = new System.Drawing.Point(39, 3);
            this.cb12_1.Name = "cb12_1";
            this.cb12_1.Size = new System.Drawing.Size(66, 21);
            this.cb12_1.TabIndex = 55;
            this.cb12_1.Text = "없 다";
            this.cb12_1.UseVisualStyleBackColor = true;
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.label11);
            this.panel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel24.Location = new System.Drawing.Point(4, 385);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(491, 27);
            this.panel24.TabIndex = 22;
            // 
            // label11
            // 
            this.label11.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label11.Location = new System.Drawing.Point(3, 4);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(330, 17);
            this.label11.TabIndex = 443;
            this.label11.Text = "현재 귀댁 자녀의 사춘기 증상이 있습니까?";
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.cb11_4);
            this.panel23.Controls.Add(this.cb11_3);
            this.panel23.Controls.Add(this.cb11_2);
            this.panel23.Controls.Add(this.cb11_1);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(502, 351);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(1366, 27);
            this.panel23.TabIndex = 21;
            // 
            // cb11_4
            // 
            this.cb11_4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb11_4.AutoSize = true;
            this.cb11_4.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb11_4.Location = new System.Drawing.Point(636, 3);
            this.cb11_4.Name = "cb11_4";
            this.cb11_4.Size = new System.Drawing.Size(151, 21);
            this.cb11_4.TabIndex = 54;
            this.cb11_4.Text = "반찬투정이 있다";
            this.cb11_4.UseVisualStyleBackColor = true;
            // 
            // cb11_3
            // 
            this.cb11_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb11_3.AutoSize = true;
            this.cb11_3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb11_3.Location = new System.Drawing.Point(457, 3);
            this.cb11_3.Name = "cb11_3";
            this.cb11_3.Size = new System.Drawing.Size(95, 21);
            this.cb11_3.TabIndex = 53;
            this.cb11_3.Text = "소식한다";
            this.cb11_3.UseVisualStyleBackColor = true;
            // 
            // cb11_2
            // 
            this.cb11_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb11_2.AutoSize = true;
            this.cb11_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb11_2.Location = new System.Drawing.Point(250, 3);
            this.cb11_2.Name = "cb11_2";
            this.cb11_2.Size = new System.Drawing.Size(134, 21);
            this.cb11_2.TabIndex = 52;
            this.cb11_2.Text = "편식이 심하다";
            this.cb11_2.UseVisualStyleBackColor = true;
            // 
            // cb11_1
            // 
            this.cb11_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb11_1.AutoSize = true;
            this.cb11_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb11_1.Location = new System.Drawing.Point(39, 3);
            this.cb11_1.Name = "cb11_1";
            this.cb11_1.Size = new System.Drawing.Size(156, 21);
            this.cb11_1.TabIndex = 51;
            this.cb11_1.Text = "골고루 잘 먹는다";
            this.cb11_1.UseVisualStyleBackColor = true;
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.label12);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel22.Location = new System.Drawing.Point(4, 351);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(491, 27);
            this.panel22.TabIndex = 20;
            // 
            // label12
            // 
            this.label12.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label12.Location = new System.Drawing.Point(3, 4);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(308, 17);
            this.label12.TabIndex = 442;
            this.label12.Text = "현재 귀댁 자녀의 식습관은 어떻습니까?";
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.cb10_3);
            this.panel21.Controls.Add(this.cb10_2);
            this.panel21.Controls.Add(this.cb10_1);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel21.Location = new System.Drawing.Point(502, 317);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(1366, 27);
            this.panel21.TabIndex = 19;
            // 
            // cb10_3
            // 
            this.cb10_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb10_3.AutoSize = true;
            this.cb10_3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb10_3.Location = new System.Drawing.Point(457, 3);
            this.cb10_3.Name = "cb10_3";
            this.cb10_3.Size = new System.Drawing.Size(117, 21);
            this.cb10_3.TabIndex = 50;
            this.cb10_3.Text = "친구가 없다";
            this.cb10_3.UseVisualStyleBackColor = true;
            // 
            // cb10_2
            // 
            this.cb10_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb10_2.AutoSize = true;
            this.cb10_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb10_2.Location = new System.Drawing.Point(250, 3);
            this.cb10_2.Name = "cb10_2";
            this.cb10_2.Size = new System.Drawing.Size(95, 21);
            this.cb10_2.TabIndex = 49;
            this.cb10_2.Text = "보통이다";
            this.cb10_2.UseVisualStyleBackColor = true;
            // 
            // cb10_1
            // 
            this.cb10_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb10_1.AutoSize = true;
            this.cb10_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb10_1.Location = new System.Drawing.Point(39, 3);
            this.cb10_1.Name = "cb10_1";
            this.cb10_1.Size = new System.Drawing.Size(117, 21);
            this.cb10_1.TabIndex = 48;
            this.cb10_1.Text = "친구가 많다";
            this.cb10_1.UseVisualStyleBackColor = true;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.label13);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(4, 317);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(491, 27);
            this.panel20.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label13.Location = new System.Drawing.Point(3, 4);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(325, 17);
            this.label13.TabIndex = 441;
            this.label13.Text = "현재 귀댁 자녀의 친구관계는 어떻습니까?";
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.cb9_5);
            this.panel19.Controls.Add(this.cb9_4);
            this.panel19.Controls.Add(this.cb9_3);
            this.panel19.Controls.Add(this.cb9_2);
            this.panel19.Controls.Add(this.cb9_1);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(502, 283);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(1366, 27);
            this.panel19.TabIndex = 17;
            // 
            // cb9_5
            // 
            this.cb9_5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb9_5.AutoSize = true;
            this.cb9_5.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb9_5.Location = new System.Drawing.Point(803, 3);
            this.cb9_5.Name = "cb9_5";
            this.cb9_5.Size = new System.Drawing.Size(117, 21);
            this.cb9_5.TabIndex = 47;
            this.cb9_5.Text = "집중력 결핍";
            this.cb9_5.UseVisualStyleBackColor = true;
            // 
            // cb9_4
            // 
            this.cb9_4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb9_4.AutoSize = true;
            this.cb9_4.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb9_4.Location = new System.Drawing.Point(636, 3);
            this.cb9_4.Name = "cb9_4";
            this.cb9_4.Size = new System.Drawing.Size(95, 21);
            this.cb9_4.TabIndex = 46;
            this.cb9_4.Text = "과잉행동";
            this.cb9_4.UseVisualStyleBackColor = true;
            // 
            // cb9_3
            // 
            this.cb9_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb9_3.AutoSize = true;
            this.cb9_3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb9_3.Location = new System.Drawing.Point(457, 3);
            this.cb9_3.Name = "cb9_3";
            this.cb9_3.Size = new System.Drawing.Size(95, 21);
            this.cb9_3.TabIndex = 45;
            this.cb9_3.Text = "명랑하다";
            this.cb9_3.UseVisualStyleBackColor = true;
            // 
            // cb9_2
            // 
            this.cb9_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb9_2.AutoSize = true;
            this.cb9_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb9_2.Location = new System.Drawing.Point(250, 3);
            this.cb9_2.Name = "cb9_2";
            this.cb9_2.Size = new System.Drawing.Size(112, 21);
            this.cb9_2.TabIndex = 44;
            this.cb9_2.Text = "소극적이다";
            this.cb9_2.UseVisualStyleBackColor = true;
            // 
            // cb9_1
            // 
            this.cb9_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb9_1.AutoSize = true;
            this.cb9_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb9_1.Location = new System.Drawing.Point(39, 3);
            this.cb9_1.Name = "cb9_1";
            this.cb9_1.Size = new System.Drawing.Size(95, 21);
            this.cb9_1.TabIndex = 43;
            this.cb9_1.Text = "활달하다";
            this.cb9_1.UseVisualStyleBackColor = true;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.label14);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(4, 283);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(491, 27);
            this.panel18.TabIndex = 16;
            // 
            // label14
            // 
            this.label14.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label14.Location = new System.Drawing.Point(3, 4);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(330, 17);
            this.label14.TabIndex = 440;
            this.label14.Text = "현재 귀댁 자녀의 평소 성격은 어떻습니까?";
            // 
            // panel17
            // 
            this.panel17.Controls.Add(this.cb8_3);
            this.panel17.Controls.Add(this.cb8_2);
            this.panel17.Controls.Add(this.cb8_1);
            this.panel17.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel17.Location = new System.Drawing.Point(502, 249);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(1366, 27);
            this.panel17.TabIndex = 15;
            // 
            // cb8_3
            // 
            this.cb8_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb8_3.AutoSize = true;
            this.cb8_3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb8_3.Location = new System.Drawing.Point(457, 3);
            this.cb8_3.Name = "cb8_3";
            this.cb8_3.Size = new System.Drawing.Size(78, 21);
            this.cb8_3.TabIndex = 42;
            this.cb8_3.Text = "하위군";
            this.cb8_3.UseVisualStyleBackColor = true;
            // 
            // cb8_2
            // 
            this.cb8_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb8_2.AutoSize = true;
            this.cb8_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb8_2.Location = new System.Drawing.Point(250, 3);
            this.cb8_2.Name = "cb8_2";
            this.cb8_2.Size = new System.Drawing.Size(66, 21);
            this.cb8_2.TabIndex = 41;
            this.cb8_2.Text = "보 통";
            this.cb8_2.UseVisualStyleBackColor = true;
            // 
            // cb8_1
            // 
            this.cb8_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb8_1.AutoSize = true;
            this.cb8_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb8_1.Location = new System.Drawing.Point(39, 3);
            this.cb8_1.Name = "cb8_1";
            this.cb8_1.Size = new System.Drawing.Size(66, 21);
            this.cb8_1.TabIndex = 40;
            this.cb8_1.Text = "우 수";
            this.cb8_1.UseVisualStyleBackColor = true;
            // 
            // panel16
            // 
            this.panel16.Controls.Add(this.label15);
            this.panel16.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel16.Location = new System.Drawing.Point(4, 249);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(491, 27);
            this.panel16.TabIndex = 14;
            // 
            // label15
            // 
            this.label15.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label15.Location = new System.Drawing.Point(3, 4);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(330, 17);
            this.label15.TabIndex = 439;
            this.label15.Text = "현재 귀댁 자녀의 학교 성적은 어떻습니까?";
            // 
            // panel15
            // 
            this.panel15.Controls.Add(this.cb7_5);
            this.panel15.Controls.Add(this.cb7_4);
            this.panel15.Controls.Add(this.cb7_3);
            this.panel15.Controls.Add(this.cb7_2);
            this.panel15.Controls.Add(this.cb7_1);
            this.panel15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel15.Location = new System.Drawing.Point(502, 215);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(1366, 27);
            this.panel15.TabIndex = 13;
            // 
            // cb7_5
            // 
            this.cb7_5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb7_5.AutoSize = true;
            this.cb7_5.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb7_5.Location = new System.Drawing.Point(803, 3);
            this.cb7_5.Name = "cb7_5";
            this.cb7_5.Size = new System.Drawing.Size(66, 21);
            this.cb7_5.TabIndex = 39;
            this.cb7_5.Text = "기 타";
            this.cb7_5.UseVisualStyleBackColor = true;
            // 
            // cb7_4
            // 
            this.cb7_4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb7_4.AutoSize = true;
            this.cb7_4.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb7_4.Location = new System.Drawing.Point(636, 3);
            this.cb7_4.Name = "cb7_4";
            this.cb7_4.Size = new System.Drawing.Size(95, 21);
            this.cb7_4.TabIndex = 38;
            this.cb7_4.Text = "척추측만";
            this.cb7_4.UseVisualStyleBackColor = true;
            // 
            // cb7_3
            // 
            this.cb7_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb7_3.AutoSize = true;
            this.cb7_3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb7_3.Location = new System.Drawing.Point(457, 3);
            this.cb7_3.Name = "cb7_3";
            this.cb7_3.Size = new System.Drawing.Size(78, 21);
            this.cb7_3.TabIndex = 37;
            this.cb7_3.Text = "저능아";
            this.cb7_3.UseVisualStyleBackColor = true;
            // 
            // cb7_2
            // 
            this.cb7_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb7_2.AutoSize = true;
            this.cb7_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb7_2.Location = new System.Drawing.Point(250, 3);
            this.cb7_2.Name = "cb7_2";
            this.cb7_2.Size = new System.Drawing.Size(66, 21);
            this.cb7_2.TabIndex = 36;
            this.cb7_2.Text = "기 형";
            this.cb7_2.UseVisualStyleBackColor = true;
            // 
            // cb7_1
            // 
            this.cb7_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb7_1.AutoSize = true;
            this.cb7_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb7_1.Location = new System.Drawing.Point(39, 3);
            this.cb7_1.Name = "cb7_1";
            this.cb7_1.Size = new System.Drawing.Size(66, 21);
            this.cb7_1.TabIndex = 35;
            this.cb7_1.Text = "정 상";
            this.cb7_1.UseVisualStyleBackColor = true;
            // 
            // panel14
            // 
            this.panel14.Controls.Add(this.label16);
            this.panel14.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel14.Location = new System.Drawing.Point(4, 215);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(491, 27);
            this.panel14.TabIndex = 12;
            // 
            // label16
            // 
            this.label16.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label16.Location = new System.Drawing.Point(3, 4);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(308, 17);
            this.label16.TabIndex = 438;
            this.label16.Text = "현재 귀댁 자녀의 몸상태는 어떻습니까?";
            // 
            // panel13
            // 
            this.panel13.Controls.Add(this.tb6_1);
            this.panel13.Controls.Add(this.cb6_4);
            this.panel13.Controls.Add(this.cb6_3);
            this.panel13.Controls.Add(this.cb6_2);
            this.panel13.Controls.Add(this.cb6_1);
            this.panel13.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel13.Location = new System.Drawing.Point(502, 181);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(1366, 27);
            this.panel13.TabIndex = 11;
            // 
            // tb6_1
            // 
            this.tb6_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb6_1.Enabled = false;
            this.tb6_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb6_1.Location = new System.Drawing.Point(381, 0);
            this.tb6_1.Name = "tb6_1";
            this.tb6_1.Size = new System.Drawing.Size(225, 27);
            this.tb6_1.TabIndex = 32;
            // 
            // cb6_4
            // 
            this.cb6_4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb6_4.AutoSize = true;
            this.cb6_4.Enabled = false;
            this.cb6_4.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb6_4.Location = new System.Drawing.Point(770, 3);
            this.cb6_4.Name = "cb6_4";
            this.cb6_4.Size = new System.Drawing.Size(61, 21);
            this.cb6_4.TabIndex = 34;
            this.cb6_4.Text = "있다";
            this.cb6_4.UseVisualStyleBackColor = true;
            // 
            // cb6_3
            // 
            this.cb6_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb6_3.AutoSize = true;
            this.cb6_3.Enabled = false;
            this.cb6_3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb6_3.Location = new System.Drawing.Point(700, 3);
            this.cb6_3.Name = "cb6_3";
            this.cb6_3.Size = new System.Drawing.Size(61, 21);
            this.cb6_3.TabIndex = 33;
            this.cb6_3.Text = "없다";
            this.cb6_3.UseVisualStyleBackColor = true;
            // 
            // cb6_2
            // 
            this.cb6_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb6_2.AutoSize = true;
            this.cb6_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb6_2.Location = new System.Drawing.Point(250, 3);
            this.cb6_2.Name = "cb6_2";
            this.cb6_2.Size = new System.Drawing.Size(605, 21);
            this.cb6_2.TabIndex = 31;
            this.cb6_2.Text = "있 다 ( 병 명 :                                                수술여부 :                " +
    "              )";
            this.cb6_2.UseVisualStyleBackColor = true;
            this.cb6_2.CheckedChanged += new System.EventHandler(this.cb6_2_CheckedChanged);
            // 
            // cb6_1
            // 
            this.cb6_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb6_1.AutoSize = true;
            this.cb6_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb6_1.Location = new System.Drawing.Point(39, 3);
            this.cb6_1.Name = "cb6_1";
            this.cb6_1.Size = new System.Drawing.Size(66, 21);
            this.cb6_1.TabIndex = 30;
            this.cb6_1.Text = "없 다";
            this.cb6_1.UseVisualStyleBackColor = true;
            // 
            // panel12
            // 
            this.panel12.Controls.Add(this.label17);
            this.panel12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel12.Location = new System.Drawing.Point(4, 181);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(491, 27);
            this.panel12.TabIndex = 10;
            // 
            // label17
            // 
            this.label17.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label17.Location = new System.Drawing.Point(3, 4);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(330, 17);
            this.label17.TabIndex = 437;
            this.label17.Text = "귀댁 자녀는 심하게 앓은 질병이 있습니까?";
            // 
            // panel11
            // 
            this.panel11.Controls.Add(this.tb5_1);
            this.panel11.Controls.Add(this.tb5_4);
            this.panel11.Controls.Add(this.tb5_3);
            this.panel11.Controls.Add(this.tb5_2);
            this.panel11.Controls.Add(this.cb5_4);
            this.panel11.Controls.Add(this.cb5_3);
            this.panel11.Controls.Add(this.cb5_2);
            this.panel11.Controls.Add(this.cb5_1);
            this.panel11.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel11.Location = new System.Drawing.Point(502, 147);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1366, 27);
            this.panel11.TabIndex = 9;
            // 
            // tb5_1
            // 
            this.tb5_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb5_1.Enabled = false;
            this.tb5_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb5_1.Location = new System.Drawing.Point(483, 0);
            this.tb5_1.Name = "tb5_1";
            this.tb5_1.Size = new System.Drawing.Size(76, 27);
            this.tb5_1.TabIndex = 25;
            // 
            // tb5_4
            // 
            this.tb5_4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb5_4.Enabled = false;
            this.tb5_4.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb5_4.Location = new System.Drawing.Point(880, 0);
            this.tb5_4.Name = "tb5_4";
            this.tb5_4.Size = new System.Drawing.Size(58, 27);
            this.tb5_4.TabIndex = 29;
            // 
            // tb5_3
            // 
            this.tb5_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb5_3.Enabled = false;
            this.tb5_3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb5_3.Location = new System.Drawing.Point(760, 0);
            this.tb5_3.Name = "tb5_3";
            this.tb5_3.Size = new System.Drawing.Size(58, 27);
            this.tb5_3.TabIndex = 28;
            // 
            // tb5_2
            // 
            this.tb5_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb5_2.Enabled = false;
            this.tb5_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb5_2.Location = new System.Drawing.Point(672, 0);
            this.tb5_2.Name = "tb5_2";
            this.tb5_2.Size = new System.Drawing.Size(58, 27);
            this.tb5_2.TabIndex = 27;
            // 
            // cb5_4
            // 
            this.cb5_4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb5_4.AutoSize = true;
            this.cb5_4.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb5_4.Location = new System.Drawing.Point(636, 3);
            this.cb5_4.Name = "cb5_4";
            this.cb5_4.Size = new System.Drawing.Size(335, 21);
            this.cb5_4.TabIndex = 26;
            this.cb5_4.Text = "                남              녀 중                 째";
            this.cb5_4.UseVisualStyleBackColor = true;
            this.cb5_4.CheckedChanged += new System.EventHandler(this.cb5_4_CheckedChanged);
            // 
            // cb5_3
            // 
            this.cb5_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb5_3.AutoSize = true;
            this.cb5_3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb5_3.Location = new System.Drawing.Point(457, 3);
            this.cb5_3.Name = "cb5_3";
            this.cb5_3.Size = new System.Drawing.Size(134, 21);
            this.cb5_3.TabIndex = 24;
            this.cb5_3.Text = "                  째";
            this.cb5_3.UseVisualStyleBackColor = true;
            this.cb5_3.CheckedChanged += new System.EventHandler(this.cb5_3_CheckedChanged);
            // 
            // cb5_2
            // 
            this.cb5_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb5_2.AutoSize = true;
            this.cb5_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb5_2.Location = new System.Drawing.Point(250, 3);
            this.cb5_2.Name = "cb5_2";
            this.cb5_2.Size = new System.Drawing.Size(66, 21);
            this.cb5_2.TabIndex = 23;
            this.cb5_2.Text = "둘 째";
            this.cb5_2.UseVisualStyleBackColor = true;
            // 
            // cb5_1
            // 
            this.cb5_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb5_1.AutoSize = true;
            this.cb5_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb5_1.Location = new System.Drawing.Point(39, 3);
            this.cb5_1.Name = "cb5_1";
            this.cb5_1.Size = new System.Drawing.Size(66, 21);
            this.cb5_1.TabIndex = 22;
            this.cb5_1.Text = "첫 째";
            this.cb5_1.UseVisualStyleBackColor = true;
            // 
            // panel10
            // 
            this.panel10.Controls.Add(this.label18);
            this.panel10.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel10.Location = new System.Drawing.Point(4, 147);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(491, 27);
            this.panel10.TabIndex = 8;
            // 
            // label18
            // 
            this.label18.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label18.Location = new System.Drawing.Point(3, 4);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(257, 17);
            this.label18.TabIndex = 436;
            this.label18.Text = "귀댁 자녀는 형제 중 몇째입니까?";
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.tb4_1);
            this.panel9.Controls.Add(this.cb4_3);
            this.panel9.Controls.Add(this.cb4_2);
            this.panel9.Controls.Add(this.cb4_1);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(502, 113);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(1366, 27);
            this.panel9.TabIndex = 7;
            // 
            // tb4_1
            // 
            this.tb4_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb4_1.Enabled = false;
            this.tb4_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb4_1.Location = new System.Drawing.Point(710, 0);
            this.tb4_1.Name = "tb4_1";
            this.tb4_1.Size = new System.Drawing.Size(58, 27);
            this.tb4_1.TabIndex = 21;
            // 
            // cb4_3
            // 
            this.cb4_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb4_3.AutoSize = true;
            this.cb4_3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb4_3.Location = new System.Drawing.Point(457, 3);
            this.cb4_3.Name = "cb4_3";
            this.cb4_3.Size = new System.Drawing.Size(349, 21);
            this.cb4_3.TabIndex = 20;
            this.cb4_3.Text = "키가 큰편이었다        출생 시                cm";
            this.cb4_3.UseVisualStyleBackColor = true;
            this.cb4_3.CheckedChanged += new System.EventHandler(this.cb4_3_CheckedChanged);
            // 
            // cb4_2
            // 
            this.cb4_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb4_2.AutoSize = true;
            this.cb4_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb4_2.Location = new System.Drawing.Point(250, 3);
            this.cb4_2.Name = "cb4_2";
            this.cb4_2.Size = new System.Drawing.Size(66, 21);
            this.cb4_2.TabIndex = 19;
            this.cb4_2.Text = "정 상";
            this.cb4_2.UseVisualStyleBackColor = true;
            // 
            // cb4_1
            // 
            this.cb4_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb4_1.AutoSize = true;
            this.cb4_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb4_1.Location = new System.Drawing.Point(39, 3);
            this.cb4_1.Name = "cb4_1";
            this.cb4_1.Size = new System.Drawing.Size(117, 21);
            this.cb4_1.TabIndex = 18;
            this.cb4_1.Text = "키가 작았다";
            this.cb4_1.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label19);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel8.Location = new System.Drawing.Point(4, 113);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(491, 27);
            this.panel8.TabIndex = 6;
            // 
            // label19
            // 
            this.label19.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label19.Location = new System.Drawing.Point(3, 4);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(323, 17);
            this.label19.TabIndex = 435;
            this.label19.Text = "귀댁 자녀의 출생 시 키는 몇 cm였습니까?";
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.cb3_4);
            this.panel7.Controls.Add(this.cb3_3);
            this.panel7.Controls.Add(this.cb3_2);
            this.panel7.Controls.Add(this.cb3_1);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(502, 79);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1366, 27);
            this.panel7.TabIndex = 5;
            // 
            // cb3_4
            // 
            this.cb3_4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb3_4.AutoSize = true;
            this.cb3_4.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb3_4.Location = new System.Drawing.Point(636, 3);
            this.cb3_4.Name = "cb3_4";
            this.cb3_4.Size = new System.Drawing.Size(104, 21);
            this.cb3_4.TabIndex = 17;
            this.cb3_4.Text = "3.5kg 이상";
            this.cb3_4.UseVisualStyleBackColor = true;
            // 
            // cb3_3
            // 
            this.cb3_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb3_3.AutoSize = true;
            this.cb3_3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb3_3.Location = new System.Drawing.Point(457, 3);
            this.cb3_3.Name = "cb3_3";
            this.cb3_3.Size = new System.Drawing.Size(95, 21);
            this.cb3_3.TabIndex = 16;
            this.cb3_3.Text = "3 ~ 3.5kg";
            this.cb3_3.UseVisualStyleBackColor = true;
            // 
            // cb3_2
            // 
            this.cb3_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb3_2.AutoSize = true;
            this.cb3_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb3_2.Location = new System.Drawing.Point(250, 3);
            this.cb3_2.Name = "cb3_2";
            this.cb3_2.Size = new System.Drawing.Size(95, 21);
            this.cb3_2.TabIndex = 15;
            this.cb3_2.Text = "2.5 ~ 3kg";
            this.cb3_2.UseVisualStyleBackColor = true;
            // 
            // cb3_1
            // 
            this.cb3_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb3_1.AutoSize = true;
            this.cb3_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb3_1.Location = new System.Drawing.Point(39, 3);
            this.cb3_1.Name = "cb3_1";
            this.cb3_1.Size = new System.Drawing.Size(99, 21);
            this.cb3_1.TabIndex = 14;
            this.cb3_1.Text = "2.5kg이하";
            this.cb3_1.UseVisualStyleBackColor = true;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label20);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(4, 79);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(491, 27);
            this.panel6.TabIndex = 4;
            // 
            // label20
            // 
            this.label20.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label20.Location = new System.Drawing.Point(3, 4);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(330, 17);
            this.label20.TabIndex = 434;
            this.label20.Text = "귀댁 자녀의 출생 시 체중은 어떠했습니까?";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.tb2_1);
            this.panel5.Controls.Add(this.cb2_5);
            this.panel5.Controls.Add(this.cb2_4);
            this.panel5.Controls.Add(this.cb2_3);
            this.panel5.Controls.Add(this.cb2_2);
            this.panel5.Controls.Add(this.cb2_1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(502, 45);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1366, 27);
            this.panel5.TabIndex = 3;
            // 
            // tb2_1
            // 
            this.tb2_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb2_1.Enabled = false;
            this.tb2_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb2_1.Location = new System.Drawing.Point(879, 0);
            this.tb2_1.Name = "tb2_1";
            this.tb2_1.Size = new System.Drawing.Size(158, 27);
            this.tb2_1.TabIndex = 13;
            // 
            // cb2_5
            // 
            this.cb2_5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb2_5.AutoSize = true;
            this.cb2_5.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb2_5.Location = new System.Drawing.Point(803, 4);
            this.cb2_5.Name = "cb2_5";
            this.cb2_5.Size = new System.Drawing.Size(253, 21);
            this.cb2_5.TabIndex = 12;
            this.cb2_5.Text = "기 타 (                                  )";
            this.cb2_5.UseVisualStyleBackColor = true;
            this.cb2_5.CheckedChanged += new System.EventHandler(this.cb2_5_CheckedChanged);
            // 
            // cb2_4
            // 
            this.cb2_4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb2_4.AutoSize = true;
            this.cb2_4.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb2_4.Location = new System.Drawing.Point(636, 3);
            this.cb2_4.Name = "cb2_4";
            this.cb2_4.Size = new System.Drawing.Size(66, 21);
            this.cb2_4.TabIndex = 11;
            this.cb2_4.Text = "조 산";
            this.cb2_4.UseVisualStyleBackColor = true;
            // 
            // cb2_3
            // 
            this.cb2_3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb2_3.AutoSize = true;
            this.cb2_3.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb2_3.Location = new System.Drawing.Point(457, 3);
            this.cb2_3.Name = "cb2_3";
            this.cb2_3.Size = new System.Drawing.Size(95, 21);
            this.cb2_3.TabIndex = 10;
            this.cb2_3.Text = "제왕절개";
            this.cb2_3.UseVisualStyleBackColor = true;
            // 
            // cb2_2
            // 
            this.cb2_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb2_2.AutoSize = true;
            this.cb2_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb2_2.Location = new System.Drawing.Point(250, 3);
            this.cb2_2.Name = "cb2_2";
            this.cb2_2.Size = new System.Drawing.Size(66, 21);
            this.cb2_2.TabIndex = 9;
            this.cb2_2.Text = "난 산";
            this.cb2_2.UseVisualStyleBackColor = true;
            // 
            // cb2_1
            // 
            this.cb2_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb2_1.AutoSize = true;
            this.cb2_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb2_1.Location = new System.Drawing.Point(39, 3);
            this.cb2_1.Name = "cb2_1";
            this.cb2_1.Size = new System.Drawing.Size(95, 21);
            this.cb2_1.TabIndex = 8;
            this.cb2_1.Text = "정상분만";
            this.cb2_1.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.tb1_1);
            this.panel4.Controls.Add(this.cb1_2);
            this.panel4.Controls.Add(this.cb1_1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(502, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1366, 34);
            this.panel4.TabIndex = 2;
            // 
            // tb1_1
            // 
            this.tb1_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tb1_1.Enabled = false;
            this.tb1_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.tb1_1.Location = new System.Drawing.Point(441, 5);
            this.tb1_1.Name = "tb1_1";
            this.tb1_1.Size = new System.Drawing.Size(152, 27);
            this.tb1_1.TabIndex = 7;
            // 
            // cb1_2
            // 
            this.cb1_2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb1_2.AutoSize = true;
            this.cb1_2.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb1_2.Location = new System.Drawing.Point(250, 8);
            this.cb1_2.Name = "cb1_2";
            this.cb1_2.Size = new System.Drawing.Size(360, 21);
            this.cb1_2.TabIndex = 6;
            this.cb1_2.Text = "있 다  (호르면 주사명:                                )";
            this.cb1_2.UseVisualStyleBackColor = true;
            this.cb1_2.CheckedChanged += new System.EventHandler(this.cb1_2_CheckedChanged);
            // 
            // cb1_1
            // 
            this.cb1_1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cb1_1.AutoSize = true;
            this.cb1_1.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.cb1_1.Location = new System.Drawing.Point(39, 8);
            this.cb1_1.Name = "cb1_1";
            this.cb1_1.Size = new System.Drawing.Size(66, 21);
            this.cb1_1.TabIndex = 5;
            this.cb1_1.Text = "없 다";
            this.cb1_1.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(491, 34);
            this.panel2.TabIndex = 0;
            // 
            // label22
            // 
            this.label22.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label22.Location = new System.Drawing.Point(3, 17);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(235, 17);
            this.label22.TabIndex = 433;
            this.label22.Text = "치료를 받은 경험이 있습니까?";
            // 
            // label23
            // 
            this.label23.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label23.Location = new System.Drawing.Point(3, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(377, 17);
            this.label23.TabIndex = 432;
            this.label23.Text = "귀댁 자녀의 임신 중 20주내 산부인과에서 호르몬";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label21);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(4, 45);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(491, 27);
            this.panel3.TabIndex = 1;
            // 
            // label21
            // 
            this.label21.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.label21.Location = new System.Drawing.Point(3, 4);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(330, 17);
            this.label21.TabIndex = 433;
            this.label21.Text = "귀댁 자녀의 출생 시 상태는 어떠했습니까?";
            // 
            // name_tb
            // 
            this.name_tb.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.name_tb.Location = new System.Drawing.Point(612, 12);
            this.name_tb.Name = "name_tb";
            this.name_tb.Size = new System.Drawing.Size(153, 27);
            this.name_tb.TabIndex = 3;
            // 
            // nametext
            // 
            this.nametext.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.nametext.AutoSize = true;
            this.nametext.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.nametext.Location = new System.Drawing.Point(519, 16);
            this.nametext.Name = "nametext";
            this.nametext.Size = new System.Drawing.Size(42, 17);
            this.nametext.TabIndex = 327;
            this.nametext.Text = "이름";
            // 
            // btn_search
            // 
            this.btn_search.Font = new System.Drawing.Font("굴림", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.btn_search.Location = new System.Drawing.Point(421, 12);
            this.btn_search.Name = "btn_search";
            this.btn_search.Size = new System.Drawing.Size(55, 29);
            this.btn_search.TabIndex = 2;
            this.btn_search.Text = "검색";
            this.btn_search.UseVisualStyleBackColor = true;
            this.btn_search.Click += new System.EventHandler(this.btn_search_Click);
            // 
            // chartnum_tb
            // 
            this.chartnum_tb.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.chartnum_tb.Location = new System.Drawing.Point(232, 12);
            this.chartnum_tb.Name = "chartnum_tb";
            this.chartnum_tb.ReadOnly = true;
            this.chartnum_tb.Size = new System.Drawing.Size(153, 27);
            this.chartnum_tb.TabIndex = 1;
            // 
            // rdatetext
            // 
            this.rdatetext.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rdatetext.AutoSize = true;
            this.rdatetext.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.rdatetext.Location = new System.Drawing.Point(845, 17);
            this.rdatetext.Name = "rdatetext";
            this.rdatetext.Size = new System.Drawing.Size(59, 17);
            this.rdatetext.TabIndex = 323;
            this.rdatetext.Text = "등록일";
            // 
            // charttext
            // 
            this.charttext.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.charttext.AutoSize = true;
            this.charttext.Font = new System.Drawing.Font("굴림", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.charttext.Location = new System.Drawing.Point(118, 15);
            this.charttext.Name = "charttext";
            this.charttext.Size = new System.Drawing.Size(81, 17);
            this.charttext.TabIndex = 322;
            this.charttext.Text = "차트 번호";
            // 
            // Munjin1Form
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.Color.WhiteSmoke;
            this.ClientSize = new System.Drawing.Size(1980, 968);
            this.ControlBox = false;
            this.Controls.Add(this.panel1);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Munjin1Form";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Munjin1Form_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel26.ResumeLayout(false);
            this.panel26.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox name_tb;
        private System.Windows.Forms.Label nametext;
        private System.Windows.Forms.Button btn_search;
        private System.Windows.Forms.TextBox chartnum_tb;
        private System.Windows.Forms.Label rdatetext;
        private System.Windows.Forms.Label charttext;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox tb18_1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb17_1;
        private System.Windows.Forms.TextBox tb16_2;
        private System.Windows.Forms.TextBox tb16_1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox cb15_5;
        private System.Windows.Forms.CheckBox cb15_4;
        private System.Windows.Forms.CheckBox cb15_3;
        private System.Windows.Forms.CheckBox cb15_2;
        private System.Windows.Forms.CheckBox cb15_1;
        private System.Windows.Forms.CheckBox cb14_6;
        private System.Windows.Forms.CheckBox cb14_5;
        private System.Windows.Forms.CheckBox cb14_4;
        private System.Windows.Forms.CheckBox cb14_3;
        private System.Windows.Forms.CheckBox cb14_2;
        private System.Windows.Forms.CheckBox cb14_1;
        private System.Windows.Forms.TextBox tb13_2;
        private System.Windows.Forms.TextBox tb13_1;
        private System.Windows.Forms.CheckBox cb13_2;
        private System.Windows.Forms.CheckBox cb13_1;
        private System.Windows.Forms.CheckBox cb12_5;
        private System.Windows.Forms.CheckBox cb12_4;
        private System.Windows.Forms.CheckBox cb12_3;
        private System.Windows.Forms.CheckBox cb12_2;
        private System.Windows.Forms.CheckBox cb12_1;
        private System.Windows.Forms.CheckBox cb11_4;
        private System.Windows.Forms.CheckBox cb11_3;
        private System.Windows.Forms.CheckBox cb11_2;
        private System.Windows.Forms.CheckBox cb11_1;
        private System.Windows.Forms.CheckBox cb10_3;
        private System.Windows.Forms.CheckBox cb10_2;
        private System.Windows.Forms.CheckBox cb10_1;
        private System.Windows.Forms.CheckBox cb9_5;
        private System.Windows.Forms.CheckBox cb9_4;
        private System.Windows.Forms.CheckBox cb9_3;
        private System.Windows.Forms.CheckBox cb9_2;
        private System.Windows.Forms.CheckBox cb9_1;
        private System.Windows.Forms.CheckBox cb8_3;
        private System.Windows.Forms.CheckBox cb8_2;
        private System.Windows.Forms.CheckBox cb8_1;
        private System.Windows.Forms.CheckBox cb7_5;
        private System.Windows.Forms.CheckBox cb7_4;
        private System.Windows.Forms.CheckBox cb7_3;
        private System.Windows.Forms.CheckBox cb7_2;
        private System.Windows.Forms.CheckBox cb7_1;
        private System.Windows.Forms.TextBox tb6_1;
        private System.Windows.Forms.CheckBox cb6_4;
        private System.Windows.Forms.CheckBox cb6_3;
        private System.Windows.Forms.CheckBox cb6_2;
        private System.Windows.Forms.CheckBox cb6_1;
        private System.Windows.Forms.TextBox tb5_4;
        private System.Windows.Forms.TextBox tb5_3;
        private System.Windows.Forms.TextBox tb5_2;
        private System.Windows.Forms.CheckBox cb5_4;
        private System.Windows.Forms.CheckBox cb5_3;
        private System.Windows.Forms.CheckBox cb5_2;
        private System.Windows.Forms.CheckBox cb5_1;
        private System.Windows.Forms.TextBox tb4_1;
        private System.Windows.Forms.CheckBox cb4_3;
        private System.Windows.Forms.CheckBox cb4_2;
        private System.Windows.Forms.CheckBox cb4_1;
        private System.Windows.Forms.CheckBox cb3_4;
        private System.Windows.Forms.CheckBox cb3_3;
        private System.Windows.Forms.CheckBox cb3_2;
        private System.Windows.Forms.CheckBox cb3_1;
        private System.Windows.Forms.TextBox tb2_1;
        private System.Windows.Forms.CheckBox cb2_5;
        private System.Windows.Forms.CheckBox cb2_4;
        private System.Windows.Forms.CheckBox cb2_3;
        private System.Windows.Forms.CheckBox cb2_2;
        private System.Windows.Forms.CheckBox cb2_1;
        private System.Windows.Forms.TextBox tb1_1;
        private System.Windows.Forms.CheckBox cb1_2;
        private System.Windows.Forms.CheckBox cb1_1;
        private System.Windows.Forms.TextBox tb5_1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DateTimePicker reg_date;
    }
}